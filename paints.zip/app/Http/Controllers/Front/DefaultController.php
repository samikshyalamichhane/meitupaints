<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Project_case;
use App\Models\Subscription;
use App\Models\Contact;
use App\Repositories\Testimonial\TestimonialRepository;
use App\Repositories\Product\ProductRepository;
use App\Repositories\Team\TeamRepository;
use App\Repositories\Project\ProjectRepository;
use App\Repositories\About\AboutRepository;
use App\Repositories\Page\PageRepository;
use Mail;
use File;
use Redirect;


class DefaultController extends Controller
{
    public function __construct(ProductRepository $product, TestimonialRepository $testimonial,TeamRepository $team, ProjectRepository $project,  PageRepository $page, AboutRepository $about){
		$this->product=$product;
		$this->testimonial=$testimonial;
		$this->project=$project;
		$this->page=$page;
        $this->team=$team;
		$this->about=$about;
        
        
	}

    public function index(){
        $testimonials=$this->testimonial->where('publish',1)->orderBy('created_at','desc')->take(5)->get();
            $about=$this->about->where('publish',1)->first();

        $products=$this->product->where('publish',1)->orderBy('created_at','desc')->take(6)->get();
        $projects=$this->project->where('publish',1)->orderBy('created_at','desc')->take(5)->get();
            return view('front.index',compact('testimonials','projects','products','about'));
        }
        
        // return view('front.career');

        public function about(){

            $about=$this->about->where('publish',1)->first();
            $team=$this->team->where('publish',1)->orderBy('created_at','desc')->take(6)->get();
            // dd($about);
            return view('front.about-us',compact('about','team'));
        }

       public function privacyPolicy(){
        
        
                return view('front.privacy-policy');
        
        
    }  
    
	 public function products(){
        // $page=$this->page->orderBy('created_at', 'desc')->where('publish',1)->first();

       $products=$this->product->where('publish',1)->orderBy('created_at','desc')->get();
        // return view('front.service',compact('services'));
        return view('front.product',compact('products'));
        }
        
         public function productInner($slug){
        $product=$this->product->where('slug',$slug)->where('publish',1)->first();
        if($product){
            $recentProducts=$this->product->orderBy('created_at','desc')->where('id','!=', $product->id)->where('publish',1)->take(4)->get();
            return view('front.product-details',compact('product','recentProducts'));
        }
    }
    

    public function projects(){
        
        $projects=$this->project->where('publish',1)->orderBy('created_at','desc')->get();
        
        return view('front.project',compact('projects'));
        
        
    }

    public function contact(){
        return view('front.contact-us');
    }

    public function contactUs(Request $request){
        // dd($request);
        $this->validate($request,[
            'name'=>'required',
            'email'=>'required|email',
            'phone'=>'required|numeric',
            'subject'=>'required',
            'message_detail'=>'required']);
    $data= $request->except('_token');
        $data=[
            'name'=>$request->name,
            'email'=>$request->email,
            'phone'=>$request->phone,
            'subject'=>$request->subject,
            'message_detail'=>$request->message_detail];

            $contact =new Contact();
        $contact->fill($data);
        $contact->save();

        Mail::send('email.contactus', $data,function ($message) use ($data) {
                        $message->to('samikshya@webhousenepal.com')->from($data['email']);
                        $message->subject('Contact');
                       });
        return Redirect::back()->withErrors(['Thank you for contacting us', 'message']);
         // return redirect()->back()->with('message','Thank you for contacting us');
        
        
        
    }


     public function subscription(Request $request){
        $this->validate($request,[
            'email'=>'required|email|unique:subscriptions'
        ]);

        $data=['email'=>$request->email];

        $success= Subscription::create($data);
        return redirect()->back()->with('subscription_message','Thank you for contacting us');

    }
}
